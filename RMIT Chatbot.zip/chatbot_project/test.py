from openai import OpenAI
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("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"))

try:
    # Make a simple API call to test the key
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": "Hello, this is a test. Can you respond with 'API key is working'?"}
        ],
        max_tokens=10
    )
    print("API Test Response:", response.choices[0].message.content)
except Exception as e:
    print(f"API Key Test Failed: {e}")